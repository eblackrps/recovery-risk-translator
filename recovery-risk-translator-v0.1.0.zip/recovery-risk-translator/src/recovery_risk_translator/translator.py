from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from recovery_risk_translator.templates import (
    exec_summary_template,
    risk_statement_template,
    recommended_actions_for_constraint,
)


@dataclass
class RiskInputs:
    scope: str
    incident_type: str
    declared_rpo: str
    declared_rto: str
    estimated_restore_window: str
    primary_constraint: str
    confidence: str  # low | medium | high
    notes: str = ""


def translate_standard(inputs: RiskInputs) -> Dict:
    summary = exec_summary_template(inputs)
    risk_statement = risk_statement_template(inputs)

    actions = recommended_actions_for_constraint(inputs.primary_constraint)
    if inputs.confidence.lower() == "low":
        actions = ["Validate assumptions with an end-to-end restore test before relying on timelines."] + actions

    if inputs.notes.strip():
        actions.append(f"Notes: {inputs.notes.strip()}")

    return {
        "mode": "standard",
        "executive_summary": summary,
        "risk_statement": risk_statement,
        "recommended_actions": actions,
    }


def translate_executive(inputs: RiskInputs) -> Dict:
    summary = (
        f"Current recovery objectives for {inputs.scope} "
        f"(RPO {inputs.declared_rpo}, RTO {inputs.declared_rto}) "
        f"are unlikely to be met during a {inputs.incident_type}-type incident. "
        f"Estimated recovery time is {inputs.estimated_restore_window}, "
        f"driven primarily by {inputs.primary_constraint} limitations."
    )

    risk = (
        "This creates a material risk of extended downtime beyond business expectations, "
        "with limited confidence that stated recovery targets can be achieved without changes."
    )

    next_steps = (
        "Leadership should assume longer recovery timelines during a major incident, "
        "validate recovery assumptions through testing, and prioritize remediation "
        "that directly reduces the primary recovery constraint."
    )

    if inputs.confidence.lower() == "high":
        risk = (
            "This creates a measurable operational risk of extended downtime beyond business expectations, "
            "despite higher confidence in current recovery estimates."
        )

    if inputs.notes.strip():
        next_steps += f" Additional context: {inputs.notes.strip()}"

    return {
        "mode": "executive",
        "executive_summary": summary,
        "risk_assessment": risk,
        "recommended_next_steps": next_steps,
    }


def translate(inputs: RiskInputs, mode: str = "standard") -> Dict:
    if mode == "executive":
        return translate_executive(inputs)
    return translate_standard(inputs)


def render_report(report: Dict, fmt: str = "text") -> str:
    mode = report.get("mode", "standard")

    if mode == "executive":
        if fmt == "md":
            return (
                "## Executive Summary\n"
                f"{report['executive_summary']}\n\n"
                "## Risk Assessment\n"
                f"{report['risk_assessment']}\n\n"
                "## Recommended Next Steps\n"
                f"{report['recommended_next_steps']}\n"
            )

        # plain text
        return (
            "Executive Summary\n"
            f"{report['executive_summary']}\n\n"
            "Risk Assessment\n"
            f"{report['risk_assessment']}\n\n"
            "Recommended Next Steps\n"
            f"{report['recommended_next_steps']}\n"
        )

    # -------- standard mode --------
    if fmt == "md":
        lines: List[str] = []
        lines.append("## Executive Summary")
        lines.append(report["executive_summary"])
        lines.append("")
        lines.append("## Risk Statement")
        lines.append(report["risk_statement"])
        lines.append("")
        lines.append("## Recommended Actions")
        for a in report["recommended_actions"]:
            lines.append(f"- {a}")
        return "\n".join(lines).strip() + "\n"

    lines = []
    lines.append("Executive Summary")
    lines.append(report["executive_summary"])
    lines.append("")
    lines.append("Risk Statement")
    lines.append(report["risk_statement"])
    lines.append("")
    lines.append("Recommended Actions")
    for a in report["recommended_actions"]:
        lines.append(f"- {a}")
    return "\n".join(lines).strip() + "\n"
