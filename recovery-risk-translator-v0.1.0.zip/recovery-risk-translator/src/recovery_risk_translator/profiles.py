from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class Profile:
    name: str
    risk_wording: str
    summary_emphasis: str
    rec_short: List[str]
    rec_standard: List[str]
    rec_detailed: List[str]


PROFILES = {
    "default": Profile(
        name="default",
        risk_wording="material operational risk",
        summary_emphasis="recovery objectives and operational impact",
        rec_short=[
            "Validate recovery timelines with a focused restore test for priority systems.",
            "Document the primary constraint and recovery sequencing assumptions.",
        ],
        rec_standard=[
            "Validate recovery timelines with an end-to-end restore test for priority systems.",
            "Reduce risk by addressing the primary constraint and documenting the restore concurrency ceiling.",
            "Document and rehearse a recovery runbook covering order of operations and dependencies.",
        ],
        rec_detailed=[
            "Run an end-to-end restore validation for Tier-1 systems, including dependencies (DNS, AD, IAM, core services).",
            "Measure the primary constraint under restore load (throughput/bandwidth/concurrency) and record the ceiling.",
            "Define recovery sequencing (what restores first, second, and why) and document decision points for incident response.",
            "Rehearse the runbook at least quarterly and after material infrastructure changes to keep assumptions current.",
        ],
    ),
    "ceo": Profile(
        name="ceo",
        risk_wording="material business risk",
        summary_emphasis="downtime exposure and business impact",
        rec_short=[
            "Confirm realistic recovery timelines for the highest-priority systems.",
            "Align leadership on what the stated RTO/RPO mean in practice during an incident.",
        ],
        rec_standard=[
            "Confirm realistic recovery timelines with a focused restore test for the highest-priority systems.",
            "Align leadership on practical RTO/RPO expectations and what “recovery complete” means for operations.",
            "Prioritize remediation that reduces downtime exposure (constraint removal, recovery sequencing, runbooks).",
        ],
        rec_detailed=[
            "Validate a Tier-1 restore path end-to-end and document what can be restored first and how long it takes.",
            "Define an executive decision tree for incident response (restore vs rebuild, communications, escalation thresholds).",
            "Invest in the constraint that most reduces downtime (restore concurrency, bandwidth, storage read performance).",
            "Ensure recovery sequencing aligns with business priorities (revenue systems, identity services, customer portals).",
        ],
    ),
    "cio": Profile(
        name="cio",
        risk_wording="operational risk",
        summary_emphasis="service impact and recoverability validation",
        rec_short=[
            "Validate Tier-1 restore timelines including dependencies and access services.",
            "Measure and document the primary bottleneck under restore load.",
        ],
        rec_standard=[
            "Run an end-to-end restore validation for Tier-1 systems, including dependencies and identity services.",
            "Measure and document the primary bottleneck (throughput, bandwidth, or concurrency) under restore load.",
            "Implement recovery sequencing and automation where possible to reduce time-to-first-service restoration.",
        ],
        rec_detailed=[
            "Test restore workflows under realistic constraints (limited staff, constrained bandwidth, partial platform failure).",
            "Capture restore concurrency ceilings and incorporate them into the runbook and recovery sequencing plan.",
            "Validate identity and core services restore order (AD/DNS/IAM, networking, storage) before application tiers.",
            "Add continuous validation where possible (scheduled restore verification) and treat results as operational evidence.",
        ],
    ),
    "audit": Profile(
        name="audit",
        risk_wording="control risk",
        summary_emphasis="evidence, validation, and documented controls",
        rec_short=[
            "Produce evidence of recoverability aligned to stated RPO/RTO requirements.",
            "Document constraints and assumptions as part of DR controls.",
        ],
        rec_standard=[
            "Produce evidence of recoverability via documented restore testing aligned to stated RPO/RTO requirements.",
            "Document assumptions and constraints (throughput, concurrency, access dependencies) as part of DR controls.",
            "Create a remediation plan with owners and dates for gaps that prevent meeting stated recovery objectives.",
        ],
        rec_detailed=[
            "Maintain documented restore test evidence (date, scope, results, bottlenecks, and corrective actions).",
            "Record assumptions/constraints (throughput, bandwidth, concurrency, access dependencies) as controlled artifacts.",
            "Define control owners and review cadence; re-test after material changes (platform, storage, network, IAM).",
            "Track remediation items to closure with dates and accountability when RTO/RPO targets are not met.",
        ],
    ),
    # CFO gets a CEO-ish framing but slightly more risk language
    "cfo": Profile(
        name="cfo",
        risk_wording="financial and operational risk",
        summary_emphasis="downtime exposure, customer impact, and cost of disruption",
        rec_short=[
            "Confirm realistic recovery timelines for highest-impact systems.",
            "Align recovery expectations with financial exposure and customer commitments.",
        ],
        rec_standard=[
            "Confirm realistic recovery timelines with a focused restore test for the highest-impact systems.",
            "Align recovery expectations with financial exposure (downtime cost) and customer commitments.",
            "Prioritize remediation that reduces outage duration and improves predictability during incidents.",
        ],
        rec_detailed=[
            "Quantify downtime exposure for Tier-1 systems and align recovery sequencing to reduce cost-of-disruption first.",
            "Validate a Tier-1 restore path end-to-end and document time-to-first-service and full service restoration windows.",
            "Prioritize investments that reduce incident duration (constraint removal, automation, validated runbooks).",
            "Ensure communications and decision thresholds are defined to reduce uncertainty and avoid prolonged outages.",
        ],
    ),
}


def get_profile(name: str) -> Profile:
    key = (name or "default").strip().lower()
    return PROFILES.get(key, PROFILES["default"])


def auto_profile_from_audience(audience: str) -> str:
    a = (audience or "CEO").strip().upper()
    if a == "CIO":
        return "cio"
    if a == "CFO":
        return "cfo"
    # default CEO
    return "ceo"


def pick_recommendations(profile: Profile, level: str) -> List[str]:
    lvl = (level or "standard").strip().lower()
    if lvl == "short":
        return list(profile.rec_short)
    if lvl == "detailed":
        return list(profile.rec_detailed)
    return list(profile.rec_standard)
