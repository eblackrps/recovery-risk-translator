from __future__ import annotations

import argparse
import datetime as _dt
import sys
from pathlib import Path
from typing import Optional, Sequence

from recovery_risk_translator.translator import RiskInputs, render_report, translate


def _default_output_dir() -> Path:
    home = Path.home()
    docs = home / "Documents"
    base = docs if docs.exists() else home
    out = base / "RecoveryRiskTranslator" / "reports"
    out.mkdir(parents=True, exist_ok=True)
    return out


def _safe_slug(s: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in s).strip("_")[:60] or "report"


def _timestamp() -> str:
    return _dt.datetime.now().strftime("%Y-%m-%d_%H%M")


def _prompt_free(label: str, default: Optional[str] = None) -> str:
    prompt = f"{label} [{default}]: " if default else f"{label}: "
    val = input(prompt).strip()
    return val or (default or "")


def _prompt_menu(
    label: str,
    options: Sequence[str],
    default_index: int = 0,
    allow_custom: bool = True,
    custom_label: str = "Other (type your own)",
) -> str:
    """
    Displays a numbered menu and returns the chosen option.
    If allow_custom=True, a final menu choice allows free-text entry.
    """
    if not options:
        raise ValueError("options cannot be empty")

    while True:
        print(f"\n{label}")
        for i, opt in enumerate(options, start=1):
            default_tag = " (default)" if (i - 1) == default_index else ""
            print(f"  {i}) {opt}{default_tag}")

        custom_choice_num = None
        if allow_custom:
            custom_choice_num = len(options) + 1
            print(f"  {custom_choice_num}) {custom_label}")

        raw = input(f"Select 1-{custom_choice_num or len(options)} [default {default_index + 1}]: ").strip()

        # default
        if raw == "":
            return options[default_index]

        # numeric choice
        if raw.isdigit():
            n = int(raw)
            if 1 <= n <= len(options):
                return options[n - 1]
            if allow_custom and custom_choice_num and n == custom_choice_num:
                val = input("Type your value: ").strip()
                if val:
                    return val
                print("Value cannot be empty.")
                continue

        # allow typing a value directly
        if allow_custom and raw:
            return raw

        print("Invalid selection. Try again.")


def run_interactive(output_dir: Optional[Path], fmt: str, mode: str, no_pause: bool) -> int:
    print("\nRecovery Risk Translator\n")

    scope = _prompt_free("Scope", "Tier-1 production workloads")

    incident_type = _prompt_menu(
        "Incident type",
        options=["ransomware", "storage failure", "site outage", "human error", "cyber incident", "app failure"],
        default_index=0,
        allow_custom=True,
        custom_label="Other (type your own incident)",
    )

    declared_rpo = _prompt_free("Declared RPO", "15 minutes")
    declared_rto = _prompt_free("Declared RTO", "1 hour")
    estimated_restore_window = _prompt_free("Estimated restore window", "6-8 hours")

    primary_constraint = _prompt_menu(
        "Primary constraint (what limits recovery the most?)",
        options=[
            "concurrency (restore throughput / parallelism)",
            "network (bandwidth / latency / segmentation)",
            "storage (IOPS / throughput / target capacity)",
            "compute (CPU/RAM constraints)",
            "security controls (scan/approval/quarantine time)",
            "runbook/process (manual steps, dependencies, sequencing)",
            "tooling/permissions (access delays, creds, RBAC)",
        ],
        default_index=0,
        allow_custom=True,
        custom_label="Other (type your own constraint)",
    )

    # store a shorter normalized label for downstream logic
    constraint_map = {
        "concurrency (restore throughput / parallelism)": "concurrency",
        "network (bandwidth / latency / segmentation)": "network",
        "storage (IOPS / throughput / target capacity)": "storage",
        "compute (CPU/RAM constraints)": "compute",
        "security controls (scan/approval/quarantine time)": "security",
        "runbook/process (manual steps, dependencies, sequencing)": "process",
        "tooling/permissions (access delays, creds, RBAC)": "access",
    }
    primary_constraint_norm = constraint_map.get(primary_constraint, primary_constraint)

    confidence = _prompt_menu(
        "Confidence (how solid are the estimates?)",
        options=["low", "medium", "high"],
        default_index=0,
        allow_custom=False,
    )

    notes = _prompt_free("Notes (optional)", "")

    mode = _prompt_menu(
        "Output type",
        options=["executive", "standard"],
        default_index=0 if mode == "executive" else 1,
        allow_custom=False,
    )

    fmt = _prompt_menu(
        "Report format",
        options=["txt", "md"],
        default_index=0 if fmt == "txt" else 1,
        allow_custom=False,
    )

    inputs = RiskInputs(
        scope=scope,
        incident_type=incident_type,
        declared_rpo=declared_rpo,
        declared_rto=declared_rto,
        estimated_restore_window=estimated_restore_window,
        primary_constraint=primary_constraint_norm,
        confidence=confidence,
        notes=notes,
    )

    report = translate(inputs, mode=mode)

    out_dir = output_dir or _default_output_dir()
    base = f"Recovery_Risk_{_safe_slug(scope)}_{_timestamp()}"
    path = out_dir / f"{base}.{'md' if fmt == 'md' else 'txt'}"

    content = render_report(report, fmt=("md" if fmt == "md" else "text"))
    path.write_text(content, encoding="utf-8")

    # Print the output to console too (your request)
    print("\n" + ("=" * 72))
    print(content.rstrip())
    print(("=" * 72) + "\n")

    print(f"Generated report:\n  {path}")

    if not no_pause:
        input("\nPress Enter to exit...")
    return 0


def main() -> int:
    p = argparse.ArgumentParser(prog="recovery-risk-translator")

    p.add_argument("--interactive", action="store_true")
    p.add_argument("--mode", choices=["executive", "standard"], default="standard")
    p.add_argument("--format", choices=["txt", "md"], default="txt")
    p.add_argument("--output-dir", default="")
    p.add_argument("--no-pause", action="store_true")

    args = p.parse_args()

    out_dir = Path(args.output_dir).expanduser().resolve() if args.output_dir else None

    # Double-click friendly default
    if args.interactive or len(sys.argv) == 1:
        return run_interactive(out_dir, args.format, args.mode, args.no_pause)

    print("Non-interactive mode not implemented for executive output.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
