from __future__ import annotations

from typing import Any


def exec_summary_template(i: Any) -> str:
    # i is expected to have attributes used below (RiskInputs), but we don't import it here.
    return (
        f"Based on current information, recovery objectives (RPO {i.declared_rpo}, RTO {i.declared_rto}) "
        f"for {i.scope} are not assured under a {i.incident_type}-style incident. Current estimates indicate "
        f"a restore window of {i.estimated_restore_window}, primarily constrained by {i.primary_constraint} limits. "
        f"{str(i.confidence).capitalize()} confidence; assumptions must be validated before relying on timelines."
    )


def risk_statement_template(i: Any) -> str:
    return (
        "This creates material operational risk: the stated RTO may be exceeded during a major incident, "
        "extending downtime beyond business expectations."
    )


def recommended_actions_for_constraint(constraint: str) -> list[str]:
    c = (constraint or "").strip().lower()

    if c == "concurrency":
        return [
            "Measure restore concurrency limits (proxies, repositories, network paths) and document the bottleneck.",
            "Reduce risk by increasing parallelism or staging restores by priority tiers.",
            "Document and rehearse a recovery runbook covering order of operations and dependencies.",
        ]
    if c == "bandwidth":
        return [
            "Validate restore throughput end-to-end (repo -> proxy -> target) and size the network path accordingly.",
            "Pre-stage critical data or prioritize low-bandwidth recovery workflows.",
            "Document and rehearse a recovery runbook covering order of operations and dependencies.",
        ]
    if c in ("storage iops", "iops"):
        return [
            "Validate restore IOPS requirements against storage capability under contention.",
            "Tune restore settings and scale storage where needed for high-priority tiers.",
            "Document and rehearse a recovery runbook covering order of operations and dependencies.",
        ]
    if c == "dependencies":
        return [
            "Map and validate restore dependencies (AD/DNS/app tiers) and required sequencing.",
            "Create a tested recovery runbook with tiered restore groups and prerequisites.",
            "Run an end-to-end restore test to confirm the dependency chain holds under stress.",
        ]
    return [
        "Validate recovery timelines with an end-to-end restore test for priority systems.",
        "Identify the dominant restore constraint (concurrency, bandwidth, storage, dependencies) and address it directly.",
        "Document and rehearse a recovery runbook covering order of operations and dependencies.",
    ]
